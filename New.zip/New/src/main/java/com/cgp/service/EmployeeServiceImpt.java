package com.cgp.service;

import com.cgp.dao.EmployeeDao;
import com.cgp.dao.EmployeeDaoImpt;
import com.cgp.domain.Employee;

public class EmployeeServiceImpt implements EmployeeService{
	EmployeeDao employeeDao=new EmployeeDaoImpt();

	@Override
	public int insert(Employee emp) {
	 
		return employeeDao.insert(emp);
	}

}
