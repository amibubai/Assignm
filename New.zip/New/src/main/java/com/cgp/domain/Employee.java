package com.cgp.domain;

import java.util.Date;

public class Employee {
	private int empNo;
	private String fname;
	private String lname;
	private double empSalary;
	private Date empDob; 
	private Date empDoj; 
	private String chkQualification;
	private String gender;
	private String empDepart;
	private String empAddress;
	
	public Employee() {
		super();
	}

	public Employee(int empNo, String fname, String lname, double empSalary, Date empDob, Date empDoj,
			String chkQualification, String gender, String empDepart, String empAddress) {
		super();
		this.empNo = empNo;
		this.fname = fname;
		this.lname = lname;
		this.empSalary = empSalary;
		this.empDob = empDob;
		this.empDoj = empDoj;
		this.chkQualification = chkQualification;
		this.gender = gender;
		this.empDepart = empDepart;
		this.empAddress = empAddress;
	}

	public int getEmpNo() {
		return empNo;
	}

	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public double getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}

	public Date getEmpDob() {
		return empDob;
	}

	public void setEmpDob(Date empDob) {
		this.empDob = empDob;
	}

	public Date getEmpDoj() {
		return empDoj;
	}

	public void setEmpDoj(Date empDoj) {
		this.empDoj = empDoj;
	}

	public String getChkQualification() {
		return chkQualification;
	}

	public void setChkQualification(String chkQualification) {
		this.chkQualification = chkQualification;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmpDepart() {
		return empDepart;
	}

	public void setEmpDepart(String empDepart) {
		this.empDepart = empDepart;
	}

	public String getEmpAddress() {
		return empAddress;
	}

	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}
	
	

}
