package com.cgp.main;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cgp.domain.Employee;
import com.cgp.service.EmployeeService;
import com.cgp.service.EmployeeServiceImpt;

 
public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	 
		String empId=request.getParameter("empNo");
		String fName=request.getParameter("fname");
		String lNmae=request.getParameter("lname");
		String empSal=request.getParameter("empSalary");
		String empDob=request.getParameter("empDob");
		String empDoj=request.getParameter("empDoj");
		String[] Qualification=request.getParameterValues("chkQualification");
		String empgender=request.getParameter("gender");
		String empDept=request.getParameter("empDepart");
		String empAddress=request.getParameter("empAddress");
		SimpleDateFormat sfd=new SimpleDateFormat("yyyy-MM-dd");
	 
		
		String qualification="";
		for (String str1 : Qualification) {
			qualification=qualification+str1;
			
		}
		int empNo=Integer.parseInt(empId);
		double salary=Double.parseDouble(empSal);
		 
		
		Employee emp=new Employee();
		emp.setEmpNo(empNo);
		emp.setFname(fName);
		emp.setLname(lNmae);
		emp.setEmpSalary(salary);
		try {
			emp.setEmpDob(sfd.parse(empDob));
			emp.setEmpDoj(sfd.parse(empDoj));
		} catch (ParseException e) {
			 
			e.printStackTrace();
		}
		
		emp.setChkQualification(qualification);
		emp.setGender(empgender);
		emp.setEmpDepart(empDept);
		emp.setEmpAddress(empAddress);
		
		EmployeeService empService=new EmployeeServiceImpt();
		int no=empService.insert(emp);
		PrintWriter out=response.getWriter();
		if(no>0)
			out.println("Record Inserted!!!!!");
		
		
		
	}

}
