package com.cgp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Date;

import com.cgp.domain.Employee;

public class EmployeeDaoImpt implements EmployeeDao {

	@Override
	public int insert(Employee emp) {
		int no = 0;
		String sql = " insert into cgpemployee values(?,?,?,?,?,?,?,?,?,?)";
		try {
			java.sql.PreparedStatement pst = getConnection().prepareStatement(sql);

			pst.setInt(1, emp.getEmpNo());
			pst.setString(2, emp.getFname());
			pst.setString(3, emp.getLname());
			pst.setDouble(4, emp.getEmpSalary());

			java.sql.Date sqlDob = new java.sql.Date(emp.getEmpDob().getTime());
			java.sql.Date sqlDoj = new java.sql.Date(emp.getEmpDoj().getTime());

			pst.setDate(5, sqlDob);
			pst.setDate(6, sqlDoj);
			pst.setString(7, emp.getEmpDepart());
			pst.setString(8, emp.getChkQualification());
			pst.setString(9, emp.getGender());
			pst.setString(10, emp.getEmpAddress());
			no = pst.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return no;

	}

	public Connection getConnection() {
		Connection con = null;
		try {

			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/classroom", "root", "India123");

		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
}