package com.cgp.dao;

import com.cgp.domain.Employee;

public interface EmployeeDao {
	public int insert(Employee emp);

}
